This is a project where we will gather data from an online source, clean it, do some manipulation 
and then do some data visualizations


```python
# We import the necessary libraries that we are going to use 
import numpy as np
import pandas as pd

```


```python
# importing the dataset
url='https://github.com/WalePhenomenon/climate_change/blob/master/fuel_ferc1.csv?raw=true'
fuel_data=pd.read_csv(url, error_bad_lines=False)
fuel_data.describe(include='all')
```

    C:\Users\user\AppData\Local\Temp\ipykernel_7968\2979116027.py:3: FutureWarning: The error_bad_lines argument has been deprecated and will be removed in a future version. Use on_bad_lines in the future.
    
    
      fuel_data=pd.read_csv(url, error_bad_lines=False)
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>record_id</th>
      <th>utility_id_ferc1</th>
      <th>report_year</th>
      <th>plant_name_ferc1</th>
      <th>fuel_type_code_pudl</th>
      <th>fuel_unit</th>
      <th>fuel_qty_burned</th>
      <th>fuel_mmbtu_per_unit</th>
      <th>fuel_cost_per_unit_burned</th>
      <th>fuel_cost_per_unit_delivered</th>
      <th>fuel_cost_per_mmbtu</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>29523</td>
      <td>29523.000000</td>
      <td>29523.000000</td>
      <td>29523</td>
      <td>29523</td>
      <td>29343</td>
      <td>2.952300e+04</td>
      <td>29523.000000</td>
      <td>29523.000000</td>
      <td>2.952300e+04</td>
      <td>29523.000000</td>
    </tr>
    <tr>
      <th>unique</th>
      <td>29523</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2315</td>
      <td>6</td>
      <td>9</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>top</th>
      <td>f1_fuel_1994_12_1_0_7</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>big stone</td>
      <td>gas</td>
      <td>mcf</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>freq</th>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>156</td>
      <td>11486</td>
      <td>11354</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>NaN</td>
      <td>118.601836</td>
      <td>2005.806050</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2.622119e+06</td>
      <td>8.492111</td>
      <td>208.649031</td>
      <td>9.175704e+02</td>
      <td>19.304354</td>
    </tr>
    <tr>
      <th>std</th>
      <td>NaN</td>
      <td>74.178353</td>
      <td>7.025483</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>9.118004e+06</td>
      <td>10.600220</td>
      <td>2854.490090</td>
      <td>6.877593e+04</td>
      <td>2091.540939</td>
    </tr>
    <tr>
      <th>min</th>
      <td>NaN</td>
      <td>1.000000</td>
      <td>1994.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1.000000e+00</td>
      <td>0.000001</td>
      <td>-276.080000</td>
      <td>-8.749370e+02</td>
      <td>-41.501000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>NaN</td>
      <td>55.000000</td>
      <td>2000.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1.381700e+04</td>
      <td>1.024000</td>
      <td>5.207000</td>
      <td>3.778500e+00</td>
      <td>1.940000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>NaN</td>
      <td>122.000000</td>
      <td>2006.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2.533220e+05</td>
      <td>5.762694</td>
      <td>26.000000</td>
      <td>1.737100e+01</td>
      <td>4.127000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>NaN</td>
      <td>176.000000</td>
      <td>2012.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1.424034e+06</td>
      <td>17.006000</td>
      <td>47.113000</td>
      <td>4.213700e+01</td>
      <td>7.745000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>NaN</td>
      <td>514.000000</td>
      <td>2018.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>5.558942e+08</td>
      <td>341.260000</td>
      <td>139358.000000</td>
      <td>7.964521e+06</td>
      <td>359278.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
# check for missing values
fuel_data.isnull().sum()
```




    record_id                         0
    utility_id_ferc1                  0
    report_year                       0
    plant_name_ferc1                  0
    fuel_type_code_pudl               0
    fuel_unit                       180
    fuel_qty_burned                   0
    fuel_mmbtu_per_unit               0
    fuel_cost_per_unit_burned         0
    fuel_cost_per_unit_delivered      0
    fuel_cost_per_mmbtu               0
    dtype: int64



This shows that we have 180 missing values on 'fuel_unit'


```python
# use groupby to count the sum of each unique value in the fuel unit column
fuel_data.groupby('fuel_unit')['fuel_unit'].count()
```




    fuel_unit
    bbl        7998
    gal          84
    gramsU      464
    kgU         110
    mcf       11354
    mmbtu       180
    mwdth        95
    mwhth       100
    ton        8958
    Name: fuel_unit, dtype: int64




```python
# let us fill up the missing values
fuel_data[['fuel_unit']]=fuel_data[['fuel_unit']].fillna(value='mcf')
```


```python
# let us check if the missing values have been filled
fuel_data.isnull().sum()
```




    record_id                       0
    utility_id_ferc1                0
    report_year                     0
    plant_name_ferc1                0
    fuel_type_code_pudl             0
    fuel_unit                       0
    fuel_qty_burned                 0
    fuel_mmbtu_per_unit             0
    fuel_cost_per_unit_burned       0
    fuel_cost_per_unit_delivered    0
    fuel_cost_per_mmbtu             0
    dtype: int64



There!!! No missing values


```python
# group by report year and count
fuel_data.groupby('report_year')['report_year'].count()
```




    report_year
    1994    1235
    1995    1201
    1996    1088
    1997    1094
    1998    1107
    1999    1050
    2000    1373
    2001    1356
    2002    1205
    2003    1211
    2004    1192
    2005    1269
    2006    1243
    2007    1264
    2008    1228
    2009    1222
    2010    1261
    2011    1240
    2012    1243
    2013    1199
    2014    1171
    2015    1093
    2016    1034
    2017     993
    2018     951
    Name: report_year, dtype: int64




```python
#group by fuel type year code and print the first year groups
fuel_data.groupby('fuel_type_code_pudl').first()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>record_id</th>
      <th>utility_id_ferc1</th>
      <th>report_year</th>
      <th>plant_name_ferc1</th>
      <th>fuel_unit</th>
      <th>fuel_qty_burned</th>
      <th>fuel_mmbtu_per_unit</th>
      <th>fuel_cost_per_unit_burned</th>
      <th>fuel_cost_per_unit_delivered</th>
      <th>fuel_cost_per_mmbtu</th>
    </tr>
    <tr>
      <th>fuel_type_code_pudl</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>coal</th>
      <td>f1_fuel_1994_12_1_0_7</td>
      <td>1</td>
      <td>1994</td>
      <td>rockport</td>
      <td>ton</td>
      <td>5377489.0</td>
      <td>16.590000</td>
      <td>18.590</td>
      <td>18.530</td>
      <td>1.121</td>
    </tr>
    <tr>
      <th>gas</th>
      <td>f1_fuel_1994_12_2_0_10</td>
      <td>2</td>
      <td>1994</td>
      <td>chickasaw</td>
      <td>mcf</td>
      <td>40533.0</td>
      <td>1.000000</td>
      <td>2.770</td>
      <td>2.770</td>
      <td>2.570</td>
    </tr>
    <tr>
      <th>nuclear</th>
      <td>f1_fuel_1994_12_2_1_1</td>
      <td>2</td>
      <td>1994</td>
      <td>joseph m. farley</td>
      <td>kgU</td>
      <td>2260.0</td>
      <td>0.064094</td>
      <td>28.770</td>
      <td>0.000</td>
      <td>0.450</td>
    </tr>
    <tr>
      <th>oil</th>
      <td>f1_fuel_1994_12_6_0_2</td>
      <td>6</td>
      <td>1994</td>
      <td>clinch river</td>
      <td>bbl</td>
      <td>6510.0</td>
      <td>5.875338</td>
      <td>32.130</td>
      <td>23.444</td>
      <td>5.469</td>
    </tr>
    <tr>
      <th>other</th>
      <td>f1_fuel_1994_12_11_0_6</td>
      <td>11</td>
      <td>1994</td>
      <td>w.f. wyman</td>
      <td>bbl</td>
      <td>55652.0</td>
      <td>0.149719</td>
      <td>14.685</td>
      <td>15.090</td>
      <td>2.335</td>
    </tr>
    <tr>
      <th>waste</th>
      <td>f1_fuel_1994_12_9_0_3</td>
      <td>9</td>
      <td>1994</td>
      <td>b.l. england</td>
      <td>ton</td>
      <td>2438.0</td>
      <td>0.015939</td>
      <td>34.180</td>
      <td>34.180</td>
      <td>1.072</td>
    </tr>
  </tbody>
</table>
</div>



Some data visualizations include: Bar plot,
    Histogram and Box plot
    


```python
# import the necessary libraries used for visualizations
import matplotlib.pyplot as plt
import seaborn as sns
```


```python
plt.figure(figsize=(7,4))
plt.xticks(rotation=90)

#This is the dataframe that we are going to use
fuel_unit=pd.DataFrame({'Unit':['BBL','GAL','GRAMSU','KGU','MCF',
                                'MMBTU','MWDTH','MWHTH','TON'],
                       'Count':[7998,84,464, 110, 11354, 180, 95,
                               100, 8958]})

# syntax for a barplot
sns.barplot(data=fuel_unit, x='Unit', y='Count')
plt.xlabel('Fuel Unit')
```




    Text(0.5, 0, 'Fuel Unit')




    
![png](output_13_1.png)
    



```python
#Because of the extreme range of values we take log of y-values
g=sns.barplot(data=fuel_unit,x='Unit', y='Count')
g.set_yscale('log')
g.set_ylim(1,12000)
plt.xlabel('Fuel Unit')
```




    Text(0.5, 0, 'Fuel Unit')




    
![png](output_14_1.png)
    



```python
# We are dealing with 20k rows of data
# Select a sample from the dataset to create a regression plot
sample_df=fuel_data.sample(n=50, random_state=4)

```


```python
# regression plot
sns.regplot(x=sample_df['utility_id_ferc1'], y=sample_df['fuel_cost_per_mmbtu'], fit_reg=False)
```




    <Axes: xlabel='utility_id_ferc1', ylabel='fuel_cost_per_mmbtu'>




    
![png](output_16_1.png)
    



```python
# For a box plot. Shows any outliers
sns.boxplot(x="fuel_type_code_pudl", y="utility_id_ferc1",palette=["m", "g"], data=fuel_data)

```




    <Axes: xlabel='fuel_type_code_pudl', ylabel='utility_id_ferc1'>




    
![png](output_17_1.png)
    



```python
# KDE plot. It depicts the probability density function of continuous data variables
sns.kdeplot(sample_df['fuel_cost_per_unit_burned'], fill=True, color='b')

```




    <Axes: xlabel='fuel_cost_per_unit_burned', ylabel='Density'>




    
![png](output_18_1.png)
    



```python

```
